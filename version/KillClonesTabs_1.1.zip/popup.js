function highlightClonesFunc() {
    var tabListBefor = [];
    var tabListAfter = [];
    var tabIndex = [];
    chrome.windows.getAll({
        populate: true
    }, function (windows) {
        windows.forEach(function (window) {
            window.tabs.forEach(function (tab) {
                tabListBefor.push({
                    tabUrl: tab.url,
                    tabId: tab.id,
                    tabIndex: tab.index
                });
            });
        });
        for (var i = 0; i < tabListBefor.length; i++) {
            for (var j = 0; j < tabListBefor.length; j++) {
                if (tabListBefor[i].tabUrl === tabListBefor[j].tabUrl && tabListBefor[i].tabId !== tabListBefor[j].tabId) {
                    tabListAfter.push(tabListBefor[j]);
                }
            }
        }
        console.log(tabListAfter);
        if (tabListAfter.length === 0) {
            document.getElementById("status").innerHTML = "All clear!";
        }
        else {
            for (var e = 0; e < tabListAfter.length; e++) {
                tabIndex.push(tabListAfter[e].tabIndex);
            }
            chrome.tabs.highlight({
                tabs: tabIndex
            });
            document.getElementById("status").innerHTML = "Got something!";
        }
    });
}

function killClonesFunc() {
    var tabListBefor = [];
    var tabListAfter = [];
    var tabId = [];
    chrome.windows.getAll({
        populate: true
    }, function (windows) {
        windows.forEach(function (window) {
            window.tabs.forEach(function (tab) {
                tabListBefor.push({
                    tabUrl: tab.url,
                    tabId: tab.id,
                    tabIndex: tab.index
                });
            });
        });
        for (var i = 0; i < tabListBefor.length; i++) {
            for (var j = 0; j < tabListBefor.length; j++) {
                if (tabListBefor[i].tabUrl === tabListBefor[j].tabUrl && tabListBefor[i].tabIndex < tabListBefor[j].tabIndex && tabListBefor[i].tabId !== tabListBefor[j].tabId) {
                    tabListAfter.push(tabListBefor[j]);
                }
            }
        }
        if (tabListAfter.length === 0) {
            document.getElementById("status").innerHTML = "No targets!";
        }
        else {
            for (var e = 0; e < tabListAfter.length; e++) {
                tabId.push(tabListAfter[e].tabId);
            }
            chrome.tabs.remove(tabId);
            document.getElementById("status").innerHTML = "Done!";
        }
    });
}

function pinAllFunk(){
    chrome.tabs.query({ currentWindow: true
    }, function (tabs) {
        var allPinned = true;
        for (var i in tabs) {
            if (!tabs[i].pinned) {
                allPinned = false;
                break;
            }
        }
        for (var j in tabs) {
            chrome.tabs.update(tabs[j].id, { pinned: !allPinned });
        }

        if (!allPinned) document.getElementById("status").innerHTML = "All Pinned!"; 
        else document.getElementById("status").innerHTML = "Unpinned!"; 
    });
}

function muteAll() {
    chrome.tabs.query({ currentWindow: true
    }, function (tabs) {
        var allMuted = true;
        for (var i in tabs) {
            if (!tabs[i].mutedInfo.muted) {
                allMuted = false;
                break;
            }
        }
        for (var j in tabs) {
            chrome.tabs.update(tabs[j].id, { muted: !allMuted });
        }

        if (!allMuted) document.getElementById("status").innerHTML = "All Muted!";
        else document.getElementById("status").innerHTML = "Unmuted!";
    });
}

document.getElementById('btnTarget').onclick = highlightClonesFunc;
document.getElementById('btnKill').onclick = killClonesFunc;
document.getElementById('btnPin').onclick = pinAllFunk;
document.getElementById('btnMuted').onclick = muteAll;